Senior Data Structure Tools
* linkedlist